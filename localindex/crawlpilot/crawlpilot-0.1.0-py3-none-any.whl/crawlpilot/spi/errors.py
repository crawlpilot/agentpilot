"""Closed set of driver-level errors, mirrored 1:1 by `gateway.errors.ErrorCode`."""

from __future__ import annotations


class DriverError(Exception):
    """Base class for all crawlpilot.spi driver errors."""


class NavigationTimeout(DriverError):
    pass


class ContextCrashed(DriverError):
    pass


class ChallengeDetected(DriverError):
    """A hard bot wall (CAPTCHA / robot check / Access Denied) was detected on
    the navigated page. Carries the classifier `verdict` (a `block_detect.Verdict`
    value, as a plain string to keep `spi` free of a `driver` import), its
    `weight` for the session layer's burn accounting, and its `scope`
    (`"privacy"` -- the only scope that raises; soft CRAWL-scope verdicts are
    surfaced on `ActionResult` instead of raised). The driver computes all three
    since it owns the classifier. `scope` defaults to `"privacy"` so existing
    call sites (and tests) that raise a bare wall keep full-rotation semantics."""

    def __init__(
        self,
        message: str,
        *,
        verdict: str | None = None,
        weight: int = 0,
        scope: str = "privacy",
    ) -> None:
        super().__init__(message)
        self.verdict = verdict
        self.weight = weight
        self.scope = scope


class StaleRefError(DriverError):
    def __init__(self, ref: str, *, epoch_superseded: bool) -> None:
        super().__init__(
            f"stale ref {ref!r} ({'epoch superseded' if epoch_superseded else 'gone within epoch'})"
        )
        self.ref = ref
        self.epoch_superseded = epoch_superseded


class TabNotFound(DriverError):
    """A `page_id`/tab reference (execute's `page_id` arg, or
    `SwitchTabAction`/`CloseTabAction`'s) that doesn't resolve to a currently
    tracked tab -- already closed, or never existed. Same NOT_FOUND family as
    "no such session", not a distinct `ErrorCode` (see `gateway/errors.py`'s
    mapping)."""

    def __init__(self, page_id: str) -> None:
        super().__init__(f"no such tab {page_id!r}")
        self.page_id = page_id


class LeaseConflict(DriverError):
    pass


class NodeLost(DriverError):
    pass


class CapacityExhausted(DriverError):
    pass


class EgressBlocked(DriverError):
    pass


class CdpNotAvailable(DriverError):
    """No CDP endpoint exists for this session: either the deployed driver
    doesn't implement `CdpEndpointCapable` at all, or this session's
    underlying context wasn't opened with `enable_cdp=True`. Same "this
    specific thing isn't available" family as `TabNotFound`/`StaleRefError`,
    not a server fault."""


class JobNotFound(DriverError):
    """No `crawl`/`batch_scrape` job with this id, or it exists but belongs
    to a different tenant -- same NOT_FOUND family as `TabNotFound`, and
    deliberately not distinguished from "wrong tenant" in the response, for
    the same reason `gateway/routes/sessions.py` doesn't leak session
    existence across tenants."""

    def __init__(self, job_id: str) -> None:
        super().__init__(f"no such job {job_id!r}")
        self.job_id = job_id


class JobCancelled(DriverError):
    """Raised when an operation (e.g. claiming a task) discovers its job was
    cancelled after the operation started -- distinct from `JobNotFound`
    (the job exists, it just won't accept further work)."""

    def __init__(self, job_id: str) -> None:
        super().__init__(f"job {job_id!r} was cancelled")
        self.job_id = job_id
